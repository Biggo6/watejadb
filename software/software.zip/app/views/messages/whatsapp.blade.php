@extends('layout')

@section('breadcrumb')
<li><a href="#">Home</a></li><li class="active">Dashboard</li>
@stop

@section('content')

<div class="row">
    <div class="col-sm-12">
        <div class="widget">

            <div class="widget-content padding">
            	<!-- Content Form Goes here -->

            	<div class="col-md-4">
            		<h4><i class="fa fa-edit"></i> Composer New SMS</h4>
            		<hr/>
            	</div>
            	<div class="col-md-8">
            		<h4><i class="fa fa-list"></i> Manage Your SMS</h4>
            		<hr/>
            	</div>

            </div>

        </div>

    </div>	
</div>


@stop

@section('specific_js_libs')




@stop