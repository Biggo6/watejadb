{{-- <footer>
    Izweb Technologies &copy; {{date('Y')}}
    <div class="footer-links pull-right">
    	<a href="#">About</a><a href="#">Support</a><a href="#">Terms of Service</a><a href="#">Legal</a><a href="#">Help</a><a href="#">Contact Us</a>
    </div>
</footer> --}}