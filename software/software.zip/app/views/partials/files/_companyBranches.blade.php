@foreach($bs as $b)
	<option value="{{$b->id}}">{{$b->name}}</option>
@endforeach