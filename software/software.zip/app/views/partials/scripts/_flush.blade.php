<script src="{{url('assets/libs/jquery/jquery-1.11.1.min.js')}}"></script>
<script type="text/javascript">
$(function(){
	$('.flush').delay(3000).fadeOut();
});
</script>