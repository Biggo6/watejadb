<?php

// Wateja Config file

return [

	'db'       => 'wateja',
	'username' => 'root',
	'password' => ''

];