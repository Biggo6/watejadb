<?php


class Group extends Eloquent{}