<?php


class LoginHistory extends Eloquent{
	protected $table = "login_history";
}