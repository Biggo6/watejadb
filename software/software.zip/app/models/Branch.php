<?php


class Branch extends Eloquent{
	
}