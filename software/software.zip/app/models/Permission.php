<?php


class Permission extends Eloquent{
	
}