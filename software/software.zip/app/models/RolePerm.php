<?php


class RolePerm extends Eloquent {
	protected $table = "roles_permissions";
}