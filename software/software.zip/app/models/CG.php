<?php


class CG extends Eloquent{
	protected $table = "customer_group";
}