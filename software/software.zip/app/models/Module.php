<?php


class Module extends Eloquent{
	
}