<?php


class Package extends Eloquent{
	protected $table = "subscription";
}