<?php


class Business extends Eloquent{
	protected $table = "business";
}