<?php


class District extends Eloquent{
	
}