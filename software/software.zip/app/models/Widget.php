<?php


class Widget extends Eloquent{}