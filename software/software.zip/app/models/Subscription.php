<?php


class Subscription extends Eloquent{
	protected $table = "company_subscription";
}