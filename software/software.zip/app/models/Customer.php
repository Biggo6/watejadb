<?php


class Customer extends Eloquent{}