<?php


class Role extends Eloquent{}